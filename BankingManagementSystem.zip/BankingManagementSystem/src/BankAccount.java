import java.util.Date;
import java.util.Scanner;

public abstract class BankAccount {
    private String accountHolderName;
    private double balance;
    private static final double MIN_BALANCE = 100.0;
    private static int accountCounter = 0;
    private int accountNumber;

    public BankAccount(String accountHolderName, double initialDeposit) {
        this.accountHolderName = accountHolderName;
        this.balance = initialDeposit;
        this.accountNumber = ++accountCounter;
    }

    public abstract void accountFeatures();


    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public double getBalance() {
        return balance;
    }


    public boolean withdraw(double amount) {
        balance -= (amount <= balance) ? amount : 0; // Conditional Operator
        return amount <= balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }


    public static int getAccountCounter() {
        return accountCounter;
    }


    public void displayAccountDetails() {
        System.out.printf("Account Number: %d\nAccount Holder: %s\nBalance: %.2f\n",
                accountNumber, accountHolderName, balance);
    }
}
