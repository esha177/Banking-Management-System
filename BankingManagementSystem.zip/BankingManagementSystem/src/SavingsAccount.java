public class SavingsAccount extends BankAccount {

    public SavingsAccount(String accountHolderName, double initialDeposit) {
        super(accountHolderName, initialDeposit);
    }

    @Override
    public void accountFeatures() {
        System.out.println("Savings Account offers 3% annual interest rate.");
    }

    public double calculateInterest() {
        return getBalance() * 0.03;
    }

    public double calculateInterest(int years) {
        return getBalance() * Math.pow(1.03, years) - getBalance();
    }
}
