import java.util.Random;
import java.util.Scanner;

public class BankSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SavingsAccount account = null;

        while (true) {
            System.out.println("\n1. Create Account\n2. Deposit\n3. Withdraw\n4. Calculate Interest\n5. Display Account Details\n6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter your name: ");
                    scanner.nextLine();
                    String name = scanner.nextLine();

                    System.out.print("Enter initial deposit: ");
                    double deposit = scanner.nextDouble();
                    account = new SavingsAccount(name, deposit);

                    System.out.println("Account created successfully!");
                    break;

                case 2:
                    if (account == null) {
                        System.out.println("No account exists. Create one first!");
                    } else {
                        System.out.print("Enter deposit amount: ");
                        double amount = scanner.nextDouble();
                        account.deposit(amount);
                        System.out.println("Deposit successful!");
                    }
                    break;

                case 3:
                    if (account == null) {
                        System.out.println("No account exists. Create one first!");
                    } else {
                        System.out.print("Enter withdrawal amount: ");
                        double amount = scanner.nextDouble();
                        if (account.withdraw(amount)) {
                            System.out.println("Withdrawal successful!");
                        } else {
                            System.out.println("Insufficient balance!");
                        }
                    }
                    break;

                case 4:
                    if (account == null) {
                        System.out.println("No account exists. Create one first!");
                    } else {
                        System.out.println("Interest (1 year): " + account.calculateInterest());
                        System.out.print("Enter number of years: ");
                        int years = scanner.nextInt();
                        System.out.println("Interest (" + years + " years): " + account.calculateInterest(years));
                    }
                    break;

                case 5:
                    if (account == null) {
                        System.out.println("No account exists. Create one first!");
                    } else {
                        account.displayAccountDetails();
                    }
                    break;

                case 6:
                    System.out.println("Thank you for using the Bank System. Goodbye!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Try again!");
            }
        }
    }
}
